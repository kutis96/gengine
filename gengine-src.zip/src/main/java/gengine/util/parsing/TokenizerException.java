package gengine.util.parsing;

/**
 *
 * @author Richard Kutina <kutinric@fel.cvut.cz>
 */
@SuppressWarnings("serial")
class TokenizerException extends Exception {
    public TokenizerException(String msg){
        super(msg);
    }
}
