package gengine.winman;

import javax.swing.JPanel;

/**
 * A JPanel extension originally meant to be used with a customized window
 * manager for games.
 *
 * @author Richard Kutina <kutinric@fel.cvut.cz>
 */
@SuppressWarnings("serial")
public class GWindow extends JPanel {

}
