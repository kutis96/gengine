package gengine.rendering;

@SuppressWarnings("serial")
public class RendererException extends Exception {
    public RendererException(String message) {
        super(message);
    }

    public RendererException() {
        super();
    }
}
